import type {Component} from "vue";

const workbenches: Record<string, Component> = {

}

export default workbenches
