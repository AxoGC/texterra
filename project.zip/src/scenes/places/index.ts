import type {Component} from "vue";
import Home from "./Home.vue";

const places: Record<string, Component> = {
  Home,
}

export default places
