import type {Component} from "vue";

const events: Record<string, Component> = {

}

export default events
